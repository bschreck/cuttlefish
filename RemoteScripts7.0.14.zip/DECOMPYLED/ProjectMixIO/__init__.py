# emacs-mode: -*- python-*-
from ProjectMixIO import ProjectMixIO

def create_instance(c_instance):
    return ProjectMixIO(c_instance)



# local variables:
# tab-width: 4
