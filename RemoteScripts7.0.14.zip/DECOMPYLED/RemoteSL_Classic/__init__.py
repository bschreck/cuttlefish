# emacs-mode: -*- python-*-
from RemoteSL import RemoteSL

def create_instance(c_instance):
    return RemoteSL(c_instance)



# local variables:
# tab-width: 4
