# emacs-mode: -*- python-*-
from MackieControlXT import MackieControlXT

def create_instance(c_instance):
    return MackieControlXT(c_instance)



# local variables:
# tab-width: 4
