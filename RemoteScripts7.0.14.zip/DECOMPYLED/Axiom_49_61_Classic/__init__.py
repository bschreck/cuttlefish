# emacs-mode: -*- python-*-
from Axiom import Axiom

def create_instance(c_instance):
    return Axiom(c_instance)



# local variables:
# tab-width: 4
