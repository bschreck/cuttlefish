# emacs-mode: -*- python-*-
from LV1_LX1 import LV1_LX1

def create_instance(c_instance):
    return LV1_LX1(c_instance)



# local variables:
# tab-width: 4
