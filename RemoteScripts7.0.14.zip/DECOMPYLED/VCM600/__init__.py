# emacs-mode: -*- python-*-
from VCM600 import VCM600

def create_instance(c_instance):
    """ Creates and returns the ADA1 script """
    return VCM600(c_instance)



# local variables:
# tab-width: 4
