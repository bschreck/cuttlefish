# emacs-mode: -*- python-*-

def create_instance(c_instance):
    return 0



# local variables:
# tab-width: 4
