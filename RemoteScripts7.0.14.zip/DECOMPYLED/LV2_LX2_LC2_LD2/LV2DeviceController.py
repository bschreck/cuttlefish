# emacs-mode: -*- python-*-
import Live
from FaderfoxDeviceController import FaderfoxDeviceController
class LV2DeviceController(FaderfoxDeviceController):
    __module__ = __name__
    __module__ = __name__

    def __init__(self, parent):
        LV2DeviceController.realinit(self, parent)



    def realinit(self, parent):
        FaderfoxDeviceController.realinit(self, parent)




# local variables:
# tab-width: 4
