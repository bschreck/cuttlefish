# emacs-mode: -*- python-*-
import Live
from LV2_LX2_LC2_LD2 import LV2_LX2_LC2_LD2
from FaderfoxScript import FaderfoxScript

def create_instance(c_instance):
    return LV2_LX2_LC2_LD2(c_instance)



# local variables:
# tab-width: 4
