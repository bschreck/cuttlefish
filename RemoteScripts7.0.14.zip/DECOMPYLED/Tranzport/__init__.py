# emacs-mode: -*- python-*-
from Tranzport import Tranzport

def create_instance(c_instance):
    return Tranzport(c_instance)



def exit_instance():
    pass


# local variables:
# tab-width: 4
