# emacs-mode: -*- python-*-
from MackieControl import MackieControl

def create_instance(c_instance):
    return MackieControl(c_instance)



# local variables:
# tab-width: 4
