# emacs-mode: -*- python-*-
from MasterControl import MasterControl

def create_instance(c_instance):
    return MasterControl(c_instance)



# local variables:
# tab-width: 4
