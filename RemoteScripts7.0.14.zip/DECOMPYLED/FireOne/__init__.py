# emacs-mode: -*- python-*-
from FireOne import FireOne

def create_instance(c_instance):
    return FireOne(c_instance)



# local variables:
# tab-width: 4
