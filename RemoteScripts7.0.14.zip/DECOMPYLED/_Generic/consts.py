# emacs-mode: -*- python-*-
NOTE_OFF_STATUS = 128
NOTE_ON_STATUS = 144
CC_STATUS = 176
NUM_NOTES = 127
NUM_CC_NO = 127
NUM_CHANNELS = 16
STATUS_ON = 127
STATUS_OFF = 0

# local variables:
# tab-width: 4
